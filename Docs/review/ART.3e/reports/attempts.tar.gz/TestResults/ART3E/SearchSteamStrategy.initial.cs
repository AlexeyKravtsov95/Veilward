// Ограниченный deterministic поиск публичных команд, без live/save mutations.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Veilward.Domain;
using Veilward.Presentation;
using Veilward.Tests.Shared;

public static class SearchSteamStrategy
{
    public static object Search()
    {
        var input=AbilityBossTrace.Load("flame");
        var config=AssetDatabase.LoadAssetAtPath<BattleScenarioConfig>("Assets/_Game/Configs/EightWaveAbilityBossV2.asset");
        var template=config.CreateSimulation();
        var cells=new List<GridCoordinate>();
        for(var x=-3;x<=3;x++)for(var y=-1;y<=1;y++)
        {var c=new GridCoordinate(x,y);if(template.Grid.GetState(c)==GridCellState.Available)cells.Add(c);}
        var rng=new System.Random(8401);var best=0;var rows=new List<object>();
        for(var trial=0;trial<12000;trial++)
        {
            var a=cells[rng.Next(cells.Count)];var b=cells[rng.Next(cells.Count)];var c=cells[rng.Next(cells.Count)];var steam=cells[rng.Next(cells.Count)];
            if(a==b||a==c||b==c||steam==a||steam==b||steam==c)continue;
            var third=trial%3!=0;var mode=trial%4;var steamWave=4+trial%2;
            var s=config.CreateSimulation();s.ChooseElement(new ChooseElementCommand("start-resonance","flame"));
            var failed="";var casts=new List<string>();var placed=false;
            s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("flame"),a));s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("flame"),b));
            for(var wave=1;wave<=7;wave++)
            {
                if(wave==3&&third&&!s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("flame"),c)).Success){failed="third funds";break;}
                if(wave==steamWave)
                {placed=s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("steam"),steam)).Success;if(!placed){failed="steam funds";break;}}
                s.StartWave();var start=s.State.Tick;
                for(var guard=0;s.State.Phase==BattlePhase.Combat&&guard<20000;guard++)
                {
                    s.Step();
                    if(mode==0)
                    foreach(var cast in input.casts.Where(q=>q.wave==wave&&q.relativeTick==s.State.Tick-start))
                    {
                        if(s.CastAbility(new CastAbilityCommand(s.AbilityState.AbilityId,new PathPosition(cast.x,cast.y),s.State.WaveIndex,s.State.Tick,s.AbilityState.NextCastSequence)).Succeeded)
                            casts.Add(wave+":"+(s.State.Tick-start)+":"+cast.x.ToString("R")+","+cast.y.ToString("R"));
                    }
                    if(mode>0&&s.AbilityState.CooldownRemainingTicks==0&&s.State.Enemies.Count>0)
                    {
                        var candidate=s.State.Enemies.Select(e=>new{e,p=s.Path.GetPosition(e.DistanceAlongPath)})
                            .Select(e=>new{e.e,e.p,score=s.State.Enemies.Count(n=>{var p=s.Path.GetPosition(n.DistanceAlongPath);return (p.X-e.p.X)*(p.X-e.p.X)+(p.Y-e.p.Y)*(p.Y-e.p.Y)<=2.25f;})})
                            .OrderByDescending(e=>e.score).ThenByDescending(e=>e.e.DistanceAlongPath).First();
                        if(candidate.score>=mode+1||candidate.e.DistanceAlongPath>s.Path.TotalLength-1)
                            if(s.CastAbility(new CastAbilityCommand(s.AbilityState.AbilityId,candidate.p,s.State.WaveIndex,s.State.Tick,s.AbilityState.NextCastSequence)).Succeeded)
                                casts.Add(wave+":"+(s.State.Tick-start)+":"+candidate.p.X.ToString("R")+","+candidate.p.Y.ToString("R"));
                    }
                    AbilityBossTrace.Clear(s);
                }
                if(s.State.Phase!=BattlePhase.WaveComplete){failed="defeat";break;}
                if(s.State.ElementProgression.PendingChoiceId!="none")s.ChooseElement(new ChooseElementCommand(s.State.ElementProgression.PendingChoiceId,wave==3?"tide":"gale"));
                s.ContinueToNextWave();
            }
            var budget=s.State.Gold+s.State.Towers.Where(t=>t.Definition.Id.Value!="steam").Sum(t=>t.InvestedGold*70/100)+(placed?110:0);
            if(failed==""&&budget>best)
            {best=budget;rows.Add(new{trial,a=a.ToString(),b=b.ToString(),c=c.ToString(),steam=steam.ToString(),third,mode,steamWave,casts,budget,hp=s.State.BaseHealth,kills=s.State.Kills});}
            if(failed==""&&budget>=495)break;
        }
        return rows;
    }
}
