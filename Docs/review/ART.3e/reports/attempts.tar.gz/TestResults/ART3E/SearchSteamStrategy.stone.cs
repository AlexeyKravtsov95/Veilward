// Ограниченный deterministic поиск публичных команд, без live/save mutations.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Veilward.Domain;
using Veilward.Presentation;
using Veilward.Tests.Shared;

public static class SearchSteamStrategy
{
    public static object Search()
    {
        var input=AbilityBossTrace.Load("flame");
        var config=AssetDatabase.LoadAssetAtPath<BattleScenarioConfig>("Assets/_Game/Configs/EightWaveAbilityBossV2.asset");
        var template=config.CreateSimulation();
        var cells=new List<GridCoordinate>();
        for(var x=-3;x<=3;x++)for(var y=-1;y<=1;y++)
        {var c=new GridCoordinate(x,y);if(template.Grid.GetState(c)==GridCellState.Available)cells.Add(c);}
        var rng=new System.Random(8409);var best=0;var rows=new List<object>();
        for(var trial=0;trial<5000;trial++)
        {
            var a=cells[rng.Next(cells.Count)];var b=cells[rng.Next(cells.Count)];var c=cells[rng.Next(cells.Count)];var steam=cells[rng.Next(cells.Count)];
            if(a==b||a==c||b==c||steam==a||steam==b||steam==c)continue;
            var third=false;var mode=trial%4;var steamWave=7;var sellWave=8;
            var s=config.CreateSimulation();s.ChooseElement(new ChooseElementCommand("start-resonance","flame"));
            var failed="";var casts=new List<string>();var placed=false;
            s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("flame"),a));
            for(var wave=1;wave<=7;wave++)
            {
                
                if(wave==3&&third&&!s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("gale"),c)).Success){failed="third funds";break;}
                if(wave==4&&!s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("stone"),c)).Success){failed="tide funds";break;}
                if(wave==steamWave)
                {
                    if(wave==sellWave)foreach(var t in s.State.Towers.ToArray())s.SellTower(t.Id);
                    placed=s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("steam"),steam)).Success;if(!placed){failed="steam funds";break;}}
                if(wave==sellWave)
                    foreach(var t in s.State.Towers.Where(t=>t.Definition.Id.Value!="steam").ToArray())s.SellTower(t.Id);
                var steamTower=s.State.Towers.FirstOrDefault(t=>t.Definition.Id.Value=="steam");
                if(steamTower!=null&&steamTower.Level<3)s.UpgradeTower(steamTower.Id);
                s.StartWave();var start=s.State.Tick;
                for(var guard=0;s.State.Phase==BattlePhase.Combat&&guard<20000;guard++)
                {
                    s.Step();
                    if(mode==0)
                    foreach(var cast in input.casts.Where(q=>q.wave==wave&&q.relativeTick==s.State.Tick-start))
                    {
                        if(s.CastAbility(new CastAbilityCommand(s.AbilityState.AbilityId,new PathPosition(cast.x,cast.y),s.State.WaveIndex,s.State.Tick,s.AbilityState.NextCastSequence)).Succeeded)
                            casts.Add(wave+":"+(s.State.Tick-start)+":"+cast.x.ToString("R")+","+cast.y.ToString("R"));
                    }
                    if(mode>0&&s.AbilityState.CooldownRemainingTicks==0&&s.State.Enemies.Count>0)
                    {
                        var chosen=default(PathPosition);var bestDamage=-1;var urgent=false;
                        void Score(PathPosition point)
                        {
                            var applied=0;
                            foreach(var e in s.State.Enemies)
                            {var q=s.Path.GetPosition(e.DistanceAlongPath);var dx=(double)point.X-q.X;var dy=(double)point.Y-q.Y;
                                if(dx*dx+dy*dy<=2.25)applied+=Math.Min(e.Health,120);}
                            if(applied>bestDamage){bestDamage=applied;chosen=point;}
                        }
                        for(var i=0;i<s.State.Enemies.Count;i++)
                        {
                            var enemy=s.State.Enemies[i];var point=s.Path.GetPosition(enemy.DistanceAlongPath);Score(point);
                            urgent|=enemy.DistanceAlongPath>=s.Path.TotalLength-1;
                            for(var j=i+1;j<s.State.Enemies.Count;j++)
                            {var q=s.Path.GetPosition(s.State.Enemies[j].DistanceAlongPath);var dx=point.X-q.X;var dy=point.Y-q.Y;
                                if(dx*dx+dy*dy<=9.001)Score(new PathPosition((point.X+q.X)*.5f,(point.Y+q.Y)*.5f));}
                        }
                        if(bestDamage>0&&(bestDamage>=mode*100||urgent))
                            if(s.CastAbility(new CastAbilityCommand(s.AbilityState.AbilityId,chosen,s.State.WaveIndex,s.State.Tick,s.AbilityState.NextCastSequence)).Succeeded)
                                casts.Add(wave+":"+(s.State.Tick-start)+":"+chosen.X.ToString("R")+","+chosen.Y.ToString("R"));
                    }
                    AbilityBossTrace.Clear(s);
                }
                if(s.State.Phase!=BattlePhase.WaveComplete){failed="defeat";break;}
                if(s.State.ElementProgression.PendingChoiceId!="none")s.ChooseElement(new ChooseElementCommand(s.State.ElementProgression.PendingChoiceId,wave==3?"stone":"tide"));
                s.ContinueToNextWave();
            }
            var budget=s.State.Gold+s.State.Towers.Where(t=>t.Definition.Id.Value!="steam").Sum(t=>t.InvestedGold*70/100)+s.State.Towers.Where(t=>t.Definition.Id.Value=="steam").Sum(t=>t.InvestedGold);
            if(failed==""&&budget>best)
            {best=budget;rows.Add(new{trial,a=a.ToString(),b=b.ToString(),c=c.ToString(),steam=steam.ToString(),third,mode,steamWave,sellWave,steamLevel=s.State.Towers.First(t=>t.Definition.Id.Value=="steam").Level,casts,budget,hp=s.State.BaseHealth,kills=s.State.Kills});}
            if(failed==""&&budget>=495)break;
        }
        return rows;
    }
}
