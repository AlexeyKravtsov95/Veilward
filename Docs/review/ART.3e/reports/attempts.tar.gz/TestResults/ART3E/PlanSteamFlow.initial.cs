// Ограниченный test-only поиск законного earned flow; production data не изменяет.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Veilward.Domain;
using Veilward.Presentation;

public static class PlanSteamFlow
{
    [Serializable] public class Script { public Command[] commands; public Cast[] casts; }
    [Serializable] public class Command { public int wave,x,y,id; public string op,type; }
    [Serializable] public class Cast { public int wave,relativeTick; public float x,y; }
    public static object Search()
    {
        var input=Veilward.Tests.Shared.AbilityBossTrace.Load("flame");
        var config=AssetDatabase.LoadAssetAtPath<BattleScenarioConfig>("Assets/_Game/Configs/EightWaveAbilityBossV2.asset");
        var rows=new List<object>();
        for(var mask=0;mask<8;mask++) for(var steamWave=0;steamWave<=7;steamWave++)
        {
            if(steamWave>0&&steamWave<4)continue;
            var s=config.CreateSimulation();s.ChooseElement(new ChooseElementCommand("start-resonance","flame"));
            var failed="";var placed=false;
            for(var wave=1;wave<=7;wave++)
            {
                foreach(var c in input.commands.Where(c=>c.wave==wave&&c.op=="place"&&wave<=6))
                {
                    if(c.wave==3&&(mask&1)!=0||c.wave==4&&(mask&2)!=0||c.wave==5&&(mask&4)!=0)continue;
                    if(!s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId(c.type),new GridCoordinate(c.x,c.y))).Success){failed="place";break;}
                }
                if(failed!="")break;
                if(wave==steamWave)
                {
                    // Освободить исходную (2,1) публичной продажей, разместить гибрид там же.
                    var old=s.State.Towers.FirstOrDefault(t=>t.Coordinate==new GridCoordinate(2,1));
                    if(old!=null)s.SellTower(old.Id);
                    placed=s.PlaceTower(new PlaceTowerCommand(new TowerDefinitionId("steam"),new GridCoordinate(2,1))).Success;
                    if(!placed){failed="steam funds";break;}
                }
                s.StartWave();var start=s.State.Tick;
                for(var guard=0;s.State.Phase==BattlePhase.Combat&&guard<20000;guard++)
                {
                    s.Step();
                    foreach(var cast in input.casts.Where(c=>c.wave==wave&&c.relativeTick==s.State.Tick-start))
                        s.CastAbility(new CastAbilityCommand(s.AbilityState.AbilityId,new PathPosition(cast.x,cast.y),s.State.WaveIndex,s.State.Tick,s.AbilityState.NextCastSequence));
                    s.ClearAttackEvents();s.ClearDamageEvents();s.ClearReactionEvents();s.ClearAbilityEvents();
                }
                if(s.State.Phase!=BattlePhase.WaveComplete){failed="defeat";break;}
                if(s.State.ElementProgression.PendingChoiceId!="none")s.ChooseElement(new ChooseElementCommand(s.State.ElementProgression.PendingChoiceId,wave==3?"tide":"gale"));
                s.ContinueToNextWave();
            }
            var budget=s.State.Gold+s.State.Towers.Where(t=>t.Definition.Id.Value!="steam").Sum(t=>t.InvestedGold*70/100)+(placed?110:0);
            rows.Add(new{mask,steamWave,failed,placed,budget,gold=s.State.Gold,hp=s.State.BaseHealth,kills=s.State.Kills,wave=s.State.WaveIndex+1});
        }
        Directory.CreateDirectory("TestResults/ART3E");
        return rows;
    }
}
